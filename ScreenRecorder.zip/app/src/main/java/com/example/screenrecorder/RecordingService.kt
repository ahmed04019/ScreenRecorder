package com.example.screenrecorder

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.*
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

class RecordingService : Service() {
    companion object {
        const val EXTRA_CODE = "extra_code"
        const val EXTRA_DATA = "extra_data"
        const val ACTION_STOP = "action_stop"
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var mediaRecorder: MediaRecorder? = null

    private var systemAudioRecorder: AudioRecord? = null
    private var micAudioRecorder: AudioRecord? = null

    private val recordingFlag = AtomicBoolean(false)
    private var systemThread: Thread? = null
    private var micThread: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopAll()
            return START_NOT_STICKY
        }

        startForeground(1, createNotification())

        val code = intent!!.getIntExtra(EXTRA_CODE, -1)
        val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)!!
        val pm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = pm.getMediaProjection(code, data)

        startRecording()

        return START_STICKY
    }

    private fun createOutputFile(prefix: String, ext: String): File {
        val dir = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "ScreenRecorder")
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "${prefix}_${System.currentTimeMillis()}.$ext")
    }

    private fun startRecording() {
        if (recordingFlag.get()) return
        recordingFlag.set(true)

        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val dpi = metrics.densityDpi

        // 1) Video via MediaRecorder (video only)
        try {
            val videoFile = createOutputFile("screen", "mp4")
            mediaRecorder = MediaRecorder().apply {
                setVideoSource(MediaRecorder.VideoSource.SURFACE)
                // do not set audio source for MP4 here; audio handled separately
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                setVideoEncodingBitRate(8_000_000)
                setVideoFrameRate(30)
                setVideoSize(width, height)
                setOutputFile(videoFile.absolutePath)
                prepare()
            }
            val surface = mediaRecorder!!.surface
            virtualDisplay = mediaProjection!!.createVirtualDisplay(
                "ScreenRecorder",
                width, height, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC,
                surface, null, null
            )
            mediaRecorder!!.start()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 2) System audio capture (API 29+)
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val config = AudioPlaybackCaptureConfiguration.Builder(mediaProjection!!)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .build()

                val format = AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(44100)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                    .build()

                val minBuf = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                systemAudioRecorder = AudioRecord.Builder()
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(minBuf * 2)
                    .setAudioPlaybackCaptureConfig(config)
                    .build()

                val sysFile = createOutputFile("system_audio", "wav")
                systemThread = Thread { writePcmToWav(systemAudioRecorder!!, sysFile) }
                systemAudioRecorder!!.startRecording()
                systemThread!!.start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 3) Microphone capture
        try {
            val sampleRate = 44100
            val channelConfig = AudioFormat.CHANNEL_IN_MONO
            val encoding = AudioFormat.ENCODING_PCM_16BIT
            val minBuf = AudioRecord.getMinBufferSize(sampleRate, channelConfig, encoding)
            micAudioRecorder = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, channelConfig, encoding, minBuf * 2)
            val micFile = createOutputFile("mic_audio", "wav")
            micThread = Thread { writePcmToWav(micAudioRecorder!!, micFile) }
            micAudioRecorder!!.startRecording()
            micThread!!.start()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun writePcmToWav(rec: AudioRecord, outFile: File) {
        val buffer = ByteArray(2048)
        var fos: FileOutputStream? = null
        var totalBytes = 0
        try {
            fos = FileOutputStream(outFile)
            // write WAV header placeholder
            fos.write(ByteArray(44))
            while (recordingFlag.get()) {
                val read = rec.read(buffer, 0, buffer.size)
                if (read > 0) {
                    fos.write(buffer, 0, read)
                    totalBytes += read
                }
            }
            fos.flush()
            fos.close()
            // now rewrite header with sizes
            val raf = RandomAccessFile(outFile, "rw")
            // RIFF header
            raf.seek(0)
            raf.writeBytes("RIFF")
            raf.writeInt(Integer.reverseBytes(36 + totalBytes))
            raf.writeBytes("WAVE")
            raf.writeBytes("fmt ")
            raf.writeInt(Integer.reverseBytes(16))
            raf.writeShort(java.lang.Short.reverseBytes(1.toShort()).toInt())
            raf.writeShort(java.lang.Short.reverseBytes( (if (rec.channelCount==1) 1 else 2).toShort()).toInt())
            raf.writeInt(Integer.reverseBytes(rec.sampleRate))
            raf.writeInt(Integer.reverseBytes(rec.sampleRate * rec.channelCount * 2))
            raf.writeShort(java.lang.Short.reverseBytes(( (rec.channelCount * 2).toShort()).toInt()).toInt())
            raf.writeShort(java.lang.Short.reverseBytes(16.toShort()).toInt())
            raf.writeBytes("data")
            raf.writeInt(Integer.reverseBytes(totalBytes))
            raf.close()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try { fos?.close() } catch (_:Exception){}
        }
    }

    private fun stopAll() {
        recordingFlag.set(false)
        try {
            systemAudioRecorder?.stop()
            systemAudioRecorder?.release()
        } catch (_: Exception) {}
        try {
            micAudioRecorder?.stop()
            micAudioRecorder?.release()
        } catch (_: Exception) {}
        try {
            mediaRecorder?.stop()
            mediaRecorder?.release()
        } catch (_: Exception) {}
        try { virtualDisplay?.release() } catch (_:Exception){}
        try { mediaProjection?.stop() } catch (_:Exception){}
        stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }

    private fun createNotification(): Notification {
        val channelId = "screen_rec_order_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val chan = NotificationChannel(channelId, "Screen Recorder", NotificationManager.IMPORTANCE_LOW)
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(chan)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Screen recording")
            .setContentText("Recording in progress")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
